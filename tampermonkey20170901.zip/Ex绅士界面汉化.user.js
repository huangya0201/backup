// ==UserScript==
// @name         Ex绅士界面汉化
// @namespace    Exhentai_叶海晨星
// @version      5%
// @description  Ex绅士界面汉化,附带E绅士界面
// @author       叶海晨星
// @include      *://exhentai.org/*
// @include      *://ul.exhentai.org/*
// @include      *://g.e-hentai.org/*
// @icon         http://exhentai.org/favicon.ico
// @require      http://code.jquery.com/jquery-1.x-git.min.js
// ==/UserScript==

function DescByLength(a, b) { //按字符长度倒序排列
    if (a.length > b.length) return 1;
    return -1;
}

function each_Replace(selector, array) {
    "use strict";
    $(selector).each(function (index) {
        $(this).html(array[$(this).html()]);
    });
}

function html_Replace(selector, array) {
    "use strict";
    var tmp = $(selector).html();
    if (tmp !== undefined) {
        for (var x in array) {
            tmp = tmp.replace(array[x].EN, array[x].CN);
        }
        $(selector).html(tmp);
    }
}

function html_each_Replace(selector, array) {
    "use strict";
    $(selector).each(function (index) {
        var tmp = $(this).html();
        if (tmp !== undefined) {
            for (var x in array) {
                tmp = tmp.replace(array[x].EN, array[x].CN);
            }
            $(this).html(tmp);
        }
    });
}

function Localization_nb() {
    "use strict";
    var nb = {};
    nb['Front Page'] = "首　　页";
    nb['Torrents'] = "种　　子";
    nb['Favorites'] = "收　　藏";
    nb['My Home'] = "我的主页";
    nb['Toplists'] = "排行榜";
    nb['Bounties'] = "悬　　赏";
    nb['News'] = "新　　闻";
    nb['Forums'] = "论　　坛";
    nb['Wiki'] = "维基百科";
    nb['HentaiVerse'] = "变态之道";
    nb['Settings'] = "设　　置";
    nb['My Galleries'] = "我的画册";
    nb['Logout'] = "退出登录";

    each_Replace("p#nb a", nb);
}

function Localization_dmi() {
    "use strict";
    var dmi = new Array();
    dmi.push({
        EN: 'Display:',
        CN: '显示方式:'
    });
    dmi.push({
        EN: 'Show Thumbnails',
        CN: '缩略图'
    });
    dmi.push({
        EN: 'Show List',
        CN: '详细列表'
    });
    dmi.push({
        EN: 'Thumbnails',
        CN: '缩略图'
    });
    dmi.push({
        EN: 'List',
        CN: '详细列表'
    });
    dmi.sort(DescByLength);
    html_Replace("div#dmi", dmi);
}

function Localization_nopm() {
    "use strict";
    $("[name='f_search']").attr("placeholder", "搜索关键字");
    $("[name='f_apply']").val("应用过滤");
    $("[name='f_clear']").val("清除过滤");
    //添加ID
    $("[onclick='toggle_advsearch_pane(this); return false']").attr("id", "advsearch");
    $("[onclick='toggle_filesearch_pane(this); return false']").attr("id", "filesearch");

    //删除事件
    $("a#advsearch").removeAttr("onclick");
    $("a#filesearch").removeAttr("onclick");
    //翻译
    var nopm_search = {};
    nopm_search['Show Advanced Options'] = "显示高级搜索";
    nopm_search['Hide Advanced Options'] = "隐藏高级搜索";
    nopm_search['Show File Search'] = "显示文件搜索";
    nopm_search['Hide File Search'] = "隐藏文件搜索";
    each_Replace("a#advsearch", nopm_search);
    each_Replace("a#filesearch", nopm_search);
    //添加事件
    $("a#advsearch").click(function () {
        if ($(this).html() == "隐藏高级搜索") {
            $(this).html("显示高级搜索");
            $("div#advdiv").hide();
            $("div#advdiv").html("");
        } else {
            $(this).html("隐藏高级搜索");
            $("div#advdiv").show();
            $("div#advdiv").html('<input type="hidden" id="advsearch" name="advsearch" value="1"/><table class="itss"><tr><td class="ic4"><input id="adv11"type="checkbox" name="f_sname" checked="checked"/><label for="adv11">搜索画册名称</label></td><td class="ic4"><input id="adv12"type="checkbox"name="f_stags"checked="checked"/><label for="adv12">搜索画册标签</label></td><td class="ic2"><input id="adv13"type="checkbox"name="f_sdesc"colspan="2"/><label for="adv13">搜索画册说明</label></td></tr><tr><td class="ic2"colspan="2"><input id="adv15"type="checkbox"name="f_storr"/><label for="adv15">搜索种子名称</label></td><td class="ic2"colspan="2"><input id="adv16"type="checkbox"name="f_sto"/><label for="adv16">仅显示有种子的画册</label></td></tr><tr><td class="ic2"colspan="2"><input id="adv21"type="checkbox"name="f_sdt1"/><label for="adv21">搜索低能标签</label></td><td class="ic2"colspan="2"><input id="adv22"type="checkbox"name="f_sdt2"/><label for="adv22">搜索低票标签</label></td></tr><tr><td class="ic2"colspan="2"><input id="adv31"type="checkbox"name="f_sh"/><label for="adv31">显示删除的画册</label></td><td class="ic2"colspan="2"><input id="adv32"type="checkbox"name="f_sr"/><label for="adv32">最小评分:</label><select id="adv42"class="stdinput imr"name="f_srdd"><option value="2">2星</option><option value="3">3星</option><option value="4">4星</option><option value="5">5星</option></select></td></tr></table>');
        }
    });
    $("a#filesearch").click(function () {
        console.log($(this).html());
        if ($(this).html() == "隐藏文件搜索") {
            $(this).html("显示文件搜索");
            $("div#fsdiv").hide();
            $("div#fsdiv").html("");
        } else {
            $(this).html("隐藏文件搜索");
            $("div#fsdiv").show();
            $("div#fsdiv").html('<form action="' + ulhost + 'image_lookup.php" method="post" enctype="multipart/form-data"><div><p style="font-weight:bold">如果要将文件搜索与类别/关键字搜索结合使用，请先上传文件。.</p><p>选择要上传的文件，然后单击文件搜索按钮。结果将显示包含文件的所有公开画册.</p><div><input type="file"name="sfile"size="40"style="font-size:8pt"/><input type="submit"name="f_sfile"value="文件搜索"style="font-size:8pt"/></div><p>对于彩色图像，系统还可以执行相似性查找以找到重新采样后的图像。</p><table class="itsf"><tr><td class="ic3"><input id="fs_similar"type="checkbox"name="fs_similar"checked="checked"/><label for="fs_similar">使用相似性扫描</label></td><td class="ic3"><input id="fs_covers"type="checkbox"name="fs_covers"/><label for="fs_covers">仅搜索封面</label></td><td class="ic3"><input id="fs_exp"type="checkbox"name="fs_exp"/><label for="fs_exp">显示过期画册</label></td></tr></table></div></form>');

        }
    });
}

function Localization_gdd() {
    //gdt1
    var gdt1 = {};
    gdt1['Posted:'] = "时　间:";
    gdt1['Parent:'] = "作　者:";
    gdt1['Visible:'] = "可　见:";
    gdt1['Language:'] = "语　言:";
    gdt1['File Size:'] = "大　小:";
    gdt1['Length:'] = "页　数:";
    gdt1['Favorited:'] = "收　藏:";
    each_Replace(".gdt1", gdt1);
    //gtd2
    var gdt2 = new Array();
    gdt2.push({
        EN: 'TR',
        CN: '译制'
    });
    gdt2.push({
        EN: 'RES',
        CN: '压缩'
    });
    gdt2.push({
        EN: 'Posted:',
        CN: '上传时间:'
    });
    gdt2.push({
        EN: 'Images:',
        CN: '画册信息:'
    });
    gdt2.push({
        EN: 'Resized:',
        CN: '缩放大小:'
    });
    gdt2.push({
        EN: 'Parent:',
        CN: '画册作者:'
    });
    gdt2.push({
        EN: 'Visible:',
        CN: '是否可见:'
    });
    gdt2.push({
        EN: 'File Size:',
        CN: '文件大小:'
    });
    gdt2.push({
        EN: 'Length:',
        CN: '画册页数:'
    });
    gdt2.push({
        EN: 'Language:',
        CN: '语言类型:'
    });
    gdt2.push({
        EN: 'Favorited:',
        CN: '收藏次数:'
    });
    gdt2.push({
        EN: 'Never',
        CN: '无人收藏'
    });
    gdt2.push({
        EN: 'Once',
        CN: '1 次'
    });
    gdt2.push({
        EN: 'For browsing',
        CN: '浏览优化'
    });
    gdt2.push({
        EN: 'Originals only',
        CN: '原画尺寸'
    });
    gdt2.push({
        EN: 'Japanese',
        CN: '日语'
    });
    gdt2.push({
        EN: 'English',
        CN: '英语'
    });
    gdt2.push({
        EN: 'Chinese',
        CN: '汉语'
    });
    gdt2.push({
        EN: 'Dutch',
        CN: '荷兰语'
    });
    gdt2.push({
        EN: 'French',
        CN: '法语'
    });
    gdt2.push({
        EN: 'German',
        CN: '德语'
    });
    gdt2.push({
        EN: 'Hungarian',
        CN: '匈牙利语'
    });
    gdt2.push({
        EN: 'Italian',
        CN: '意大利语'
    });
    gdt2.push({
        EN: 'Korean',
        CN: '韩语'
    });
    gdt2.push({
        EN: 'Polish',
        CN: '波兰语'
    });
    gdt2.push({
        EN: 'Portuguese',
        CN: '葡萄牙语'
    });
    gdt2.push({
        EN: 'Russian',
        CN: '俄罗斯语'
    });
    gdt2.push({
        EN: 'Spanish',
        CN: '西班牙语'
    });
    gdt2.push({
        EN: 'Thai',
        CN: '泰语'
    });
    gdt2.push({
        EN: 'Vietnamese',
        CN: '越南语'
    });
    gdt2.push({
        EN: 'N\A',
        CN: '未知'
    });
    gdt2.push({
        EN: 'Other',
        CN: '其他'
    });
    gdt2.push({
        EN: '(T)',
        CN: '(译)'
    });
    gdt2.push({
        EN: 'pages',
        CN: '页'
    });
    gdt2.push({
        EN: 'times',
        CN: '次'
    });
    gdt2.push({
        EN: 'None',
        CN: '无'
    });
    gdt2.push({
        EN: 'Yes',
        CN: '是'
    });
    gdt2.push({
        EN: 'No',
        CN: '否'
    });
    gdt2.sort(DescByLength); //进行排序
    html_Replace("div#gdd tbody", gdt2);
}

function Localization_gdr() {
    $("a#favoritelink").html('<img src="http://ehgt.org/g/mr.gif"> 添加到收藏');
    $("td#rating_label").html("平均:" + average_rating.toFixed(2));
    $("div#gdr").removeAttr("onmouseout");
    $("div#gdr").mouseout(function () {
        if (rate_xhr === undefined) {
            update_rating_image(Math.round(display_rating * 2));
            if (average_rating === 0) {
                $("td#rating_label").html("尚未有人评分");
            } else {
                $("td#rating_label").html("平均:" + average_rating.toFixed(2));
            }
        }
    });

    $("div#gdr #grt1").text("评分:");
    $("div#gdr map area").each(function (index) {
        $(this).removeAttr("onmouseover");
        $(this).mouseover(function () {
            if (rate_xhr === undefined) {
                update_rating_image(index + 1);
                $("td#rating_label").html("给" + ((index + 1) / 2).toFixed(1) + "星");
            }
        });
    });

}

function Localization_gd5() {
    var gd5 = [];
    gd5.push({
        EN: "Report Gallery",
        CN: "举报画册"
    });
    gd5.push({
        EN: "Archive Download",
        CN: "下载画册"
    });
    gd5.push({
        EN: "Torrent Download",
        CN: "下载种子"
    });
    gd5.push({
        EN: "Show Gallery Stats",
        CN: "显示画册评分"
    });
    gd5.push({
        EN: "Get External Gallery",
        CN: "获取分享代码"
    });
    gd5.push({
        EN: "Petition to Expunge",
        CN: "申请删除"
    });
    gd5.push({
        EN: "Petition to Rename",
        CN: "申请改名"
    });
    gd5.sort(DescByLength);
    html_Replace("div#gd5", gd5);
}

function Localization_taglist_tc() {
    var tc = {};
    tc['language:'] = "语　言:";
    tc['parody:'] = "出　处:";
    tc['group:'] = "分　组:";
    tc['character:'] = "角　色:";
    tc['artist:'] = "画　师:";
    tc['female:'] = "女　性:";
    tc['male:'] = "男　性:";
    tc['misc:'] = "杂　项:";
    tc['reclass:'] = "重分类:";
    each_Replace("div#taglist td.tc", tc);
}

function Change_Width() {
    "use strict";
    $("div.ido").css("max-width", "98%");
    $(".itg").css("max-width", "98%");
    $("div#searchbox.idi").css("width", "800px");
}

//Change_Width();
Localization_nb();
Localization_nopm();
Localization_dmi();
Localization_gdd();
Localization_gdr();
Localization_taglist_tc();
Localization_gd5();